Lab for Us Brand Kit

Contents:
- logo.png, mascot.png
- squiggles/ and dividers/ : brand graphics
- palette/ : colors as txt, css, and json

Hashtag: #MadeAtLabForUs  (paired with #labforus)
